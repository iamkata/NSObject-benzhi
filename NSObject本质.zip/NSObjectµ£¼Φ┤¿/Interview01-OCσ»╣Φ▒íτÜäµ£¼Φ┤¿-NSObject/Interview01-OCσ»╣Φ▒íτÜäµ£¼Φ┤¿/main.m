//
//  main.m
//  Interview01-OC对象的本质
//
//  Created by MJ Lee on 2018/4/1.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <malloc/malloc.h>

//// NSObject定义
//@interface NSObject {
//    Class isa;
//}
//@end

// NSObject Implementation NSObject底层实现
struct NSObject_IMPL {
    Class isa; // 指针在64位系统占8个字节 在32位系统占4字节
};

// 指针
// typedef struct objc_class *Class;

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSObject *obj = [[NSObject alloc] init];
        // 16个字节
        
        // Returns the size of instances of a class.
        // 获得NSObject实例对象的成员变量所占用的大小 打印 8
        NSLog(@"%zd", class_getInstanceSize([NSObject class]));
        
        // 获得obj指针所指向内存的大小 打印 16
        //一个16进制位代表4个二进制位,两个16进制位代表8个二进制位 (一个字节占用8个二进制位大小)
        //[关于为什么一个字节占8个二进制](https://blog.csdn.net/qq_33666602/article/details/79959523)
        NSLog(@"%zd", malloc_size((__bridge const void *)obj));
        
        // 什么平台的代码
        // 不同平台支持的代码肯定是不一样
        // Windows、mac、iOS
        // 模拟器(i386)、32bit(armv7)、64bit（arm64）
    }
    return 0;
}
