//
//  main.m
//  Interview01-OC对象的本质
//
//  Created by MJ Lee on 2018/4/1.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <malloc/malloc.h>

//NSObject的实现 这个结构体只占用8个字节,只不过硬性分配给他16个字节
struct NSObject_IMPL {
    Class isa;
};


//下面代码的C++实现
struct Student_IMPL {
    //struct NSObject_IMPL NSObject_IVARS;
    Class isa;
    int _no;
    int _age;
};


@interface Student : NSObject
{
    @public
    int _no;
    int _age;
}
@end

@implementation Student

@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Student *stu = [[Student alloc] init];
        stu->_no = 4;
        stu->_age = 5;
        
        NSLog(@"%zd", class_getInstanceSize([Student class]));
        //16
        NSLog(@"%zd", malloc_size((__bridge const void *)stu));
        //16  前面8个放isa 后面4个放_no(4个字节) 最后4个放_age(4个字节)
        
        //注意:
        //用结构体指针指向stu,再通过结构体直接访问成员变量,访问成功,说明对象本质就是结构体
        struct Student_IMPL *stuImpl = (__bridge struct Student_IMPL *)stu;
        NSLog(@"no is %d, age is %d", stuImpl->_no, stuImpl->_age);
        //no is 4, age is 5
    }
    return 0;
}
