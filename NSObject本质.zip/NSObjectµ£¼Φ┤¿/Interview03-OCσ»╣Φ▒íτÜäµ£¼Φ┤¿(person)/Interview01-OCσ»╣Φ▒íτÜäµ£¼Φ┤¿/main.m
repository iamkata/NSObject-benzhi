//
//  main.m
//  Interview01-OC对象的本质
//
//  Created by MJ Lee on 2018/4/1.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <malloc/malloc.h>

//struct NSObject_IMPL {
//    Class isa;
//};
//
//struct Person_IMPL {
//    struct NSObject_IMPL NSObject_IVARS; // 8
//    int _age; // 4
//}; // 一共16字节

//就算没OC源码里面规定的至少为16
//由于结构体的内存对齐：结构体的大小必须是最大成员大小的倍数 从这个角度看也是16

//
//struct Student_IMPL {
//    struct Person_IMPL Person_IVARS; // 16
//    int _no; // 4
//}; // 一共16字节   (虽然Person_IMPL占用16字节,但是他有4字节空出来的,所以_no正好放在那里)


//struct Person_IMPL {
//    struct NSObject_IMPL NSObject_IVARS;
//    int _no;
//    int _height
//};

// Person
@interface Person : NSObject
{
    @public
    int _age;
}
@property (nonatomic, assign) int height;
//可以看出实例对象的内存中多了一个_height,但是没有方法

//(setter和getter方法为什么不和成员变量放一块呢,因为方法一份就够了,多个对象都可以调
//用,没必要放实例对象的内存中,方法放到类对象和方法列表里面)

@end

@implementation Person

@end

// Student
//@interface Student : Person
//{
//    int _no;
//}
//@end
//
//@implementation Student
//
//@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        Student *stu = [[Student alloc] init];
//        class_getInstanceSize 获取的是对齐后的内存大小
//        NSLog(@"stu - %zd", class_getInstanceSize([Student class]));  //16
//        NSLog(@"stu - %zd", malloc_size((__bridge const void *)stu));  //16
//
        Person *person = [[Person alloc] init];
        [person setHeight:10];
        [person height];
        person->_age = 20; //->是直接访问成员变量
        
        Person *person1 = [[Person alloc] init];
        person1->_age = 10;
        
        
        Person *person2 = [[Person alloc] init];
        person2->_age = 30;
        
//        NSLog(@"person - %zd", class_getInstanceSize([Person class])); //16
//        NSLog(@"person - %zd", malloc_size((__bridge const void *)person)); //16
    }
    return 0;
}
