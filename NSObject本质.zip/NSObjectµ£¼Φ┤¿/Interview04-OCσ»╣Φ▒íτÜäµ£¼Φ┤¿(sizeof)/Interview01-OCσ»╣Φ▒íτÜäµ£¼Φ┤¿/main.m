//
//  main.m
//  Interview01-OC对象的本质
//
//  Created by MJ Lee on 2018/4/8.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <malloc/malloc.h>
#import <objc/runtime.h>

struct NSObject_IMPL {
    Class isa;
};

struct MJPerson_IMPL {
    struct NSObject_IMPL NSObject_IVARS; // 8
    int _age; // 4
    int _height; // 4
    int _no; // 4
}; // 计算结构体大小，内存对齐，24

@interface MJPerson : NSObject
{
    int _age;
    int _height;
    int _no;
}
@end

@implementation MJPerson

@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        MJPerson *p = [[MJPerson alloc] init];
        
        //sizeof和class_getInstanceSize都是返回至少需要多少内存,而malloc_size返回的是实际需要的
        //但是他们也有不同点:sizeof传进来一个类型进来,我告诉你类型有多大,比如int,sizeof是个运算符,不是函数  class_getInstanceSize传一个类进来,我告诉你最终创建的实例大小,是个函数
        
        NSLog(@"%zd", sizeof(struct MJPerson_IMPL)); // 24
        NSLog(@"%zd %zd",
              class_getInstanceSize([MJPerson class]), // 24
              malloc_size((__bridge const void *)(p))); // 32
        //为什么我需要24字节你给我32呢?
        //因为ios系统也有内存对齐的概念,内存必须是16的倍数,就算你只需要24字节,传给我24,我也会传给你32字节
        //这也解释了,为什么NSObject里面只有一个isa指针(占8字节),但是还是给他16字节的原因了
    }
    return 0;
}
